export const MenuItems = [
  {
    title: "Swap",
    url: "/DemoForMilkShake/",
    cName: "nav-links",
  },
  {
    title: "Liquidity",
    url: "/DemoForMilkShake/liquidity",
    cName: "nav-links",
  },
];
